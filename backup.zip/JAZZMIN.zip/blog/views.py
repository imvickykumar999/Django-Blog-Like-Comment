from django.shortcuts import render, get_object_or_404, redirect
from .forms import CommentForm
from .models import Article, ContactQueries

def home(request):
    articles = Article.objects.all()
    return render(request, 'index.html', {'articles': articles})

def contact(request):
    success_message = None
    if request.method == 'POST':
        name = request.POST.get('name')
        mailid = request.POST.get('mailid')
        phone = request.POST.get('phone')
        subject = request.POST.get('subject')
        message = request.POST.get('message')

        # Save to the ContactQueries model
        ContactQueries.objects.create(
            name=name,
            mailid=mailid,
            phone=phone,
            subject=subject,
            message=message
        )

        success_message = "Your message has been sent. Thank you!"

    return render(request, 'contact.html', {'success_message': success_message})

def blogs(request):
    articles = Article.objects.all()
    return render(request, 'blog.html', {'articles': articles})

def blog_details(request, article_slug):
    article = get_object_or_404(Article, article_slug=article_slug)
    return render(request, 'blog-details.html', {'article': article})

def about(request):
    return render(request, 'about.html')

def blog_details(request, article_slug):
    article = get_object_or_404(Article, article_slug=article_slug)
    comments = article.comments.filter(active=True)
    new_comment = None

    if request.method == 'POST':
        comment_form = CommentForm(data=request.POST)
        if comment_form.is_valid():
            new_comment = comment_form.save(commit=False)
            new_comment.article = article
            new_comment.save()
            return redirect('article_detail', article_slug=article_slug)
    else:
        comment_form = CommentForm()

    return render(request, 'blog-details.html', {
        'article': article,
        'comments': comments,
        'new_comment': new_comment,
        'comment_form': comment_form
    })
